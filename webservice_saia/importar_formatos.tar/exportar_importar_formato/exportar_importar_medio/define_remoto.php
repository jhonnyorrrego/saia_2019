<?php
if(!defined("SERVIDOR_IMPORTAR")){
	define("SERVIDOR_IMPORTAR",'http://75.101.166.85/saia_demos/saia_nucleo/saia/webservice_saia/exportar_importar_formato/importar_formato/receptor_importar.php');
}




?> 