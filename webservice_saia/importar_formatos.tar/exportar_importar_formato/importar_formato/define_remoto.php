<?php
if(!defined("SERVIDOR_IMPORTAR")){
	define("SERVIDOR_IMPORTAR",'http://172.28.20.27/saia_pruebas/saia/webservice_saia/exportar_importar_formato/importar_formato/');
}

?> 