<?php
if(!defined("SERVIDOR_EXPORTAR")){
	define("SERVIDOR_EXPORTAR",'http://75.101.166.85/saia_release1/saia/webservice_saia/exportar_importar_formato/exportar_formato/receptor_exportar.php');
}
if(!defined("SERVIDOR_MEDIO")){
	define("SERVIDOR_MEDIO",'http://75.101.166.85/saia_release1/saia/webservice_saia/exportar_importar_formato/exportar_importar_medio/exportar_importar_medio.php');
}


//http://75.101.166.85/saia_release1/saia/index_actualizacion.php
?> 